import React, { useState } from 'react';
import FriendList from './components/friendList';
import ChatWindow from './components/chatWindow';

const App = () => {
  const [selectedFriend, setSelectedFriend] = useState(null)
  const [messages, setMessages] = useState({
    Sanket: [],
    Ashish: [],
    Rohit: [],
  })

  const addMessage = (friend, message) => {
    setMessages({
      ...messages,
      [friend]: [...messages[friend], message],
    })
  }

  return (
    <div className="app">
      <FriendList onSelectFriend={setSelectedFriend} />
      {selectedFriend && (
        <ChatWindow
          friend={selectedFriend}
          messages={messages[selectedFriend]}
          addMessage={addMessage}
        />
      )}
    </div>
  )
}

export default App;
