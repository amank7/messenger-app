import React from 'react';
import '../styles/friendList.css'

const friends = ['Sanket', 'Ashish', 'Rohit']

const FriendList = ({ onSelectFriend }) => {
    return (
        <div className="friend-list">
            {friends.map((friend, index) => (
                <div key={index} onClick={() => onSelectFriend(friend)}>
                    {friend}
                </div>
            ))}
        </div>
    )
}

export default FriendList;
