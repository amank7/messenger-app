import React, { useState } from 'react';
import '../styles/chatWindow.css'

const ChatWindow = ({ friend, messages, addMessage }) => {
    const [newMessage, setNewMessage] = useState('')

    const handleSendMessage = () => {
        if (newMessage.trim() !== '') {
            addMessage(friend, { text: newMessage, sender: 'You' })
            setNewMessage('')
        }
    };

    return (
        <div className="chat-window">
            <div className="messages">
                {messages.map((msg, index) => (
                    <div key={index} className="message">
                        <strong>{msg.sender}:</strong> {msg.text}
                    </div>
                ))}
            </div>
            <input
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                placeholder={`Message ${friend}`}
            />
            <button onClick={handleSendMessage}>Send</button>
        </div>
    );
};

export default ChatWindow
